const menuicon = document.querySelector('#menu-icon');
const navbar = document.querySelector('.navbar');

menuicon.addEventListener('click', () => {
    menuicon.classList.toggle('ri-close-line');
    navbar.classList.toggle('active');
});
